package com.reserve.Dao;

import com.reserve.bean.DiningReservation;
import com.reserve.bean.ResortReservation;
import com.reserve.util.GuestException;

/**
 * The Interface GuestDao.
 */
public interface GuestDao {

	/**
	 * Gets the dining details.
	 *
	 * @param guestId
	 *            the guest id
	 * @return the booking details
	 */
	public DiningReservation getDiningDetails(int guestId);

	/**
	 * Gets the resort details.
	 *
	 * @param guestId
	 *            the guest id
	 * @return the resort details
	 */
	public ResortReservation getResortDetails(int guestId);

	/**
	 * Cancel dining.
	 *
	 * @param diningReservationNum
	 *            the dining reservation num
	 * @return the dining reservation
	 */
	public DiningReservation cancelDining(int diningReservationNum);

	/**
	 * Cancel resort.
	 *
	 * @param resortReservationNum
	 *            the resort reservation num
	 * @return the resort reservation
	 */
	public ResortReservation cancelResort(int resortReservationNum);

	/**
	 * Book resort.
	 *
	 * @param resortReservation
	 *            the resort reservation
	 * @param guestId
	 *            the guest id
	 * @return the int
	 */
	public int bookResort(ResortReservation resortReservation, int guestId);

	/**
	 * Book dining.
	 *
	 * @param diningReservation
	 *            the dining reservation
	 * @param guestId
	 *            the guest id
	 * @return the int
	 */
	public int bookDining(DiningReservation diningReservation, int guestId);
}
