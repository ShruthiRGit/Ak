package com.reserve.Dao;

import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

import com.reserve.bean.DiningReservation;
import com.reserve.bean.ResortReservation;
import com.reserve.mapper.DiningRowMapper;
import com.reserve.mapper.ResortRowMapper;
import com.reserve.util.GuestException;

/**
 * @author srajalak
 *
 */
@Transactional
@Repository
public class GuestDaoImpl implements GuestDao {

	/** The jdbc template. */
	@Autowired
	private JdbcTemplate jdbcTemplate;

	/** The date. */
	Date date = new Date();

	/** The sql date. */
	java.sql.Date sqlDate = new java.sql.Date(date.getTime());

	/** The resort number. */
	int resortNumber = 0;

	/** The dining number. */
	int diningNumber = 0;

	/**
	 * Gets the dining details.
	 *
	 * @param guestId
	 *            the guest id
	 * @return the booking details
	 */
	public DiningReservation getDiningDetails(int guestId) {
		DiningReservation diningReservation = null;
		RowMapper<DiningReservation> rowMapper = new DiningRowMapper();

		diningReservation = jdbcTemplate.queryForObject("SELECT * FROM dining WHERE guest_id = ?",
				new Object[] { guestId }, rowMapper);
		if (ObjectUtils.isEmpty(diningReservation)) {
			return null;
		}
		return diningReservation;

	}

	/**
	 * Gets the resort details.
	 *
	 * @param guestId
	 *            the guest id
	 * @return the resort details
	 */
	@Override
	public ResortReservation getResortDetails(int guestId) {
		ResortReservation resortReservation = null;
		RowMapper<ResortReservation> rowmapper = new ResortRowMapper();

		resortReservation = jdbcTemplate.queryForObject("SELECT * FROM resort WHERE guest_id = ?",
				new Object[] { guestId }, rowmapper);
		if (ObjectUtils.isEmpty(resortReservation)) {
			return null;
		}
		return resortReservation;
	}

	/**
	 * Cancel dining.
	 *
	 * @param diningReservationNum
	 *            the dining reservation num
	 * @return the dining reservation
	 */
	@Override
	public DiningReservation cancelDining(int diningReservationNum) {
		DiningReservation diningReservation = null;
		RowMapper<DiningReservation> rowMapper = new DiningRowMapper();
		int count = 0;

		count = jdbcTemplate.update("UPDATE dining set status = ? where d_reservation_number = ?",
				new Object[] { "CANCELED", diningReservationNum });
		if (count != 0) {
			diningReservation = jdbcTemplate.queryForObject("SELECT * FROM dining WHERE d_reservation_number = ?",
					new Object[] { diningReservationNum }, rowMapper);
		}

		return diningReservation;
	}

	/**
	 * Cancel resort.
	 *
	 * @param resortReservationNum
	 *            the resort reservation num
	 * @return the resort reservation
	 */
	@Override
	public ResortReservation cancelResort(int resortReservationNum) {
		ResortReservation resortReservation = null;
		RowMapper<ResortReservation> rowMapper = new ResortRowMapper();
		int count = 0;

		count = jdbcTemplate.update("UPDATE resort set status = ? where r_reservation_number = ?",
				new Object[] { "CANCELED", resortReservationNum });
		if (count != 0) {
			resortReservation = jdbcTemplate.queryForObject("SELECT * FROM resort WHERE r_reservation_number = ?",
					new Object[] { resortReservationNum }, rowMapper);
		}

		return resortReservation;
	}

	/**
	 * Book resort.
	 *
	 * @param resortReservation
	 *            the resort reservation
	 * @param guestId
	 *            the guest id
	 * @return the int
	 */
	@Override
	public int bookResort(ResortReservation resortReservation, int guestId) {
		int count = 0;
		int resortReservationNumber = 0;
		String status = "BOOKED";

		count = jdbcTemplate.update(
				"insert into resort (r_reservation_number,guest_id,room_type,arrival_date,departure_date,no_of_people,status,created_date,updated_date) VALUES(?,?,?,?,?,?,?,?,?)",
				new Object[] { ++resortNumber, guestId, resortReservation.getRoomType(),
						resortReservation.getArrivalDate(), resortReservation.getDepartureDate(),
						resortReservation.getNoOfPeople(), status, sqlDate, sqlDate });

		if (count != 0) {
			ResortReservation resortReservation1 = null;
			RowMapper<ResortReservation> rowmapper = new ResortRowMapper();
			resortReservation1 = jdbcTemplate.queryForObject("SELECT * FROM resort WHERE guest_id = ?",
					new Object[] { guestId }, rowmapper);
			resortReservationNumber = resortReservation1.getReservationNumber();
		}

		return resortReservationNumber;
	}

	/**
	 * Book dining.
	 *
	 * @param diningReservation
	 *            the dining reservation
	 * @param guestId
	 *            the guest id
	 * @return the int
	 */
	@Override
	public int bookDining(DiningReservation diningReservation, int guestId) {
		int count = 0;
		int diningReservationNumber = 0;
		String status = "BOOKED";

		count = jdbcTemplate.update(
				"insert into dining (d_reservation_number,guest_id,dining_type,arrival_date,no_of_people,status,created_date,updated_date) VALUES(?,?,?,?,?,?,?,?)",
				new Object[] { ++diningNumber, guestId, diningReservation.getDiningType(),
						diningReservation.getArrivalDate(), diningReservation.getNoOfPeople(), status, sqlDate,
						sqlDate });

		if (count != 0) {
			DiningReservation diningReservation1 = null;
			RowMapper<DiningReservation> rowmapper = new DiningRowMapper();
			diningReservation1 = jdbcTemplate.queryForObject("SELECT * FROM dining WHERE guest_id = ?",
					new Object[] { guestId }, rowmapper);
			diningReservationNumber = diningReservation1.getDiningReservationNum();
		}

		return diningReservationNumber;
	}

}