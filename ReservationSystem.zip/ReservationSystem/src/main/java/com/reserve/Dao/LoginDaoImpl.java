package com.reserve.Dao;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.reserve.bean.Guest;
import com.reserve.mapper.GuestRowMapper;
import com.reserve.util.GuestException;

/**
 * The Class LoginDaoImpl.
 *
 * @author srajalak
 */
@Transactional
@Repository
public class LoginDaoImpl implements LoginDao {

	/** The jdbc template. */
	@Autowired
	private JdbcTemplate jdbcTemplate;

	/** The id. */
	int id = 0;

	/** The date. */
	Date date = new Date();

	/** The sql date. */
	java.sql.Date sqlDate = new java.sql.Date(date.getTime());

	/*
	 * 
	 * 
	 * addGuest(com.reserve.bean.Guest)
	 */
	@Override
	public int addGuest(Guest guest) throws GuestException {
		int count = 0;
		RowMapper<Guest> rowMapper = new GuestRowMapper();

		String email = guest.getEmail();
		String sql = "select count(*) from guest";
		id = queryForInt(sql);
		for (int i = 1; i <= id; i++) {
			Guest guest1 = jdbcTemplate.queryForObject("SELECT * from guest WHERE guest_id = ?", new Object[] { i },
					rowMapper);
			if (email.equalsIgnoreCase(guest1.getEmail())) {
				return 0;
			}
		}

		count = jdbcTemplate.update(
				"insert into guest (guest_id,email,first_name,last_name,address,phone,password,created_date,updated_date) VALUES(?,?,?,?,?,?,?,?,?)",
				new Object[] { ++id, guest.getEmail(), guest.getFirstName(), guest.getLastName(), guest.getAddress(),
						guest.getPhone(), guest.getPassword(), sqlDate, sqlDate });

		if (count == 0) {
			throw new GuestException("Guest details provided is incorrect");
		}
		return id;
	}

	/*
	 * 
	 * 
	 * validateGuest(java.lang.String, java.lang.String)
	 */
	@Override
	public boolean validateGuest(String emailId, String password) throws GuestException {
		RowMapper<Guest> rowmapper = new GuestRowMapper();
		Guest guest = new Guest();
		try {
			guest = jdbcTemplate.queryForObject("SELECT * FROM guest WHERE email = ? AND password= ?",
					new Object[] { emailId, password }, rowmapper);
		} catch (DataAccessException e) {
			throw new GuestException("Login credentials are incorrect");
		}
		return true;
	}

	/**
	 * Query for int.
	 *
	 * @param sql
	 *            the sql
	 * @return the int
	 * @throws DataAccessException
	 *             the data access exception
	 */
	@Deprecated
	public int queryForInt(String sql) throws DataAccessException {
		return jdbcTemplate.queryForObject(sql, Integer.class);
	}

}
