package com.reserve.bean;

import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class ResponseBooking.
 *
 * @author srajalak
 */
public class ResponseBooking {

	/** The guest id. */
	private int guestId;
	
	/** The dining reservations. */
	private List<DiningReservation> diningReservations;
	
	/** The resort reservations. */
	private List<ResortReservation> resortReservations;
	
	/** The error message. */
	private String errorMessage;

	/**
	 * Instantiates a new response booking.
	 */
	public ResponseBooking() {
		super();
	}

	/**
	 * Instantiates a new response booking.
	 *
	 * @param guestId the guest id
	 * @param diningReservations the dining reservations
	 * @param resortReservations the resort reservations
	 * @param errorMessage the error message
	 */
	public ResponseBooking(int guestId, List<DiningReservation> diningReservations,
			List<ResortReservation> resortReservations, String errorMessage) {
		super();
		this.guestId = guestId;
		this.diningReservations = diningReservations;
		this.resortReservations = resortReservations;
		this.errorMessage = errorMessage;
	}

	/**
	 * Gets the error message.
	 *
	 * @return the error message
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * Sets the error message.
	 *
	 * @param errorMessage the new error message
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * Gets the guest id.
	 *
	 * @return the guest id
	 */
	public int getGuestId() {
		return guestId;
	}

	/**
	 * Sets the guest id.
	 *
	 * @param guestId the new guest id
	 */
	public void setGuestId(int guestId) {
		this.guestId = guestId;
	}

	/**
	 * Gets the dining reservations.
	 *
	 * @return the dining reservations
	 */
	public List<DiningReservation> getDiningReservations() {
		return diningReservations;
	}

	/**
	 * Sets the dining reservations.
	 *
	 * @param diningReservations the new dining reservations
	 */
	public void setDiningReservations(List<DiningReservation> diningReservations) {
		this.diningReservations = diningReservations;
	}

	/**
	 * Gets the resort reservation.
	 *
	 * @return the resort reservation
	 */
	public List<ResortReservation> getResortReservation() {
		return resortReservations;
	}

	/**
	 * Sets the resort reservations.
	 *
	 * @param resortReservation the new resort reservations
	 */
	public void setResortReservations(List<ResortReservation> resortReservation) {
		this.resortReservations = resortReservation;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ResponseBooking [guestId=" + guestId + ", diningReservations=" + diningReservations
				+ ", resortReservation=" + resortReservations + "]";
	}

}
