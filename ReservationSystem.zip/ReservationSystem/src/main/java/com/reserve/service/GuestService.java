package com.reserve.service;

import com.reserve.bean.DiningReservation;
import com.reserve.bean.ResortReservation;
import com.reserve.util.GuestException;

/**
 * The Interface GuestService.
 */
/**
 * @author srajalak
 *
 */
public interface GuestService {

	/**
	 * Gets the dining details.
	 *
	 * @param guestId the guest id
	 * @return the booking details
	 * @throws GuestException the guest exception
	 */
	public DiningReservation getDiningDetails(int guestId);

	/**
	 * Gets the resort details.
	 *
	 * @param guestId the guest id
	 * @return the resort details
	 * @throws GuestException the guest exception
	 */
	public ResortReservation getResortDetails(int guestId);

	/**
	 * Cancel dining.
	 *
	 * @param diningReservationNum the dining reservation num
	 * @return the dining reservation
	 * @throws GuestException the guest exception
	 */
	public DiningReservation cancelDining(int diningReservationNum);

	/**
	 * Cancel resort.
	 *
	 * @param resortReservationNum the resort reservation num
	 * @return the resort reservation
	 * @throws GuestException the guest exception
	 */
	public ResortReservation cancelResort(int resortReservationNum);

	/**
	 * Book resort.
	 *
	 * @param resortReservation the resort reservation
	 * @param guestId the guest id
	 * @return the int
	 * @throws GuestException the guest exception
	 */
	public int bookResort(ResortReservation resortReservation, int guestId);

	/**
	 * Book dining.
	 *
	 * @param diningReservation the dining reservation
	 * @param guestId the guest id
	 * @return the int
	 * @throws GuestException the guest exception
	 */
	public int bookDining(DiningReservation diningReservation, int guestId);
}
