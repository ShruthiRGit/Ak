package com.reserve.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reserve.Dao.GuestDao;
import com.reserve.bean.DiningReservation;
import com.reserve.bean.ResortReservation;
import com.reserve.util.GuestException;

/**
 * The Class GuestServiceImpl.
 *
 * @author srajalak
 */
@Service
public class GuestServiceImpl implements GuestService {

	/** The guest dao. */
	@Autowired
	private GuestDao guestDao;

	/**
	 * Gets the dining details.
	 *
	 * @param guestId
	 *            the guest id
	 * @return the booking details
	 * @throws GuestException
	 *             the guest exception
	 */
	@Override
	public DiningReservation getDiningDetails(int guestId) {

		return guestDao.getDiningDetails(guestId);
	}

	/**
	 * Gets the resort details.
	 *
	 * @param guestId
	 *            the guest id
	 * @return the resort details
	 * @throws GuestException
	 *             the guest exception
	 */
	@Override
	public ResortReservation getResortDetails(int guestId) {
		return guestDao.getResortDetails(guestId);
	}

	/**
	 * Cancel dining.
	 *
	 * @param diningReservationNum
	 *            the dining reservation num
	 * @return the dining reservation
	 * @throws GuestException
	 *             the guest exception
	 */
	@Override
	public DiningReservation cancelDining(int diningReservationNum) {
		return guestDao.cancelDining(diningReservationNum);
	}

	/**
	 * Cancel resort.
	 *
	 * @param resortReservationNum
	 *            the resort reservation num
	 * @return the resort reservation
	 * @throws GuestException
	 *             the guest exception
	 */
	@Override
	public ResortReservation cancelResort(int resortReservationNum) {
		return guestDao.cancelResort(resortReservationNum);
	}

	/**
	 * Book resort.
	 *
	 * @param resortReservation
	 *            the resort reservation
	 * @param guestId
	 *            the guest id
	 * @return the int
	 * @throws GuestException
	 *             the guest exception
	 */
	@Override
	public int bookResort(ResortReservation resortReservation, int guestId) {
		return guestDao.bookResort(resortReservation, guestId);
	}

	/**
	 * Book dining.
	 *
	 * @param diningReservation
	 *            the dining reservation
	 * @param guestId
	 *            the guest id
	 * @return the int
	 * @throws GuestException
	 *             the guest exception
	 */
	@Override
	public int bookDining(DiningReservation diningReservation, int guestId) {
		return guestDao.bookDining(diningReservation, guestId);
	}
}
