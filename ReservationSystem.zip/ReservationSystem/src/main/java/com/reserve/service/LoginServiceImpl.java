package com.reserve.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reserve.Dao.LoginDao;
import com.reserve.bean.Guest;
import com.reserve.util.GuestException;

/**
 * The Class LoginServiceImpl.
 */
/**
 * @author srajalak
 *
 */
@Service
public class LoginServiceImpl implements LoginService {

	/** The login dao. */
	@Autowired
	private LoginDao loginDao;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.reserve.service.LoginService#addGuest(com.reserve.bean.Guest)
	 */
	@Override
	public int addGuest(Guest guest) throws Exception {
		return loginDao.addGuest(guest);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.reserve.service.LoginService#validateGuest(java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public boolean validateGuest(String emailId, String password) throws GuestException {
		return loginDao.validateGuest(emailId, password);
	}

}
