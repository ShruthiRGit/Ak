package com.reserve.util;

/**
 * @author srajalak
 *
 */
public class GuestException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5942275254513048603L;

	/** The error type. */
	private String errorType;

	/** The error message. */
	private String errorMessage;

	/**
	 * Instantiates a new guest exception.
	 *
	 * @param errorType
	 *            the error type
	 * @param errorMessage
	 *            the error message
	 */
	public GuestException(String errorType, String errorMessage) {
		super();
		this.errorType = errorType;
		this.errorMessage = errorMessage;
	}

	/**
	 * Instantiates a new guest exception.
	 */
	public GuestException() {
	}

	/**
	 * Instantiates a new guest exception.
	 *
	 * @param message
	 *            the message
	 */
	public GuestException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new guest exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public GuestException(Throwable cause) {
		super(cause);
	}

	/**
	 * Instantiates a new guest exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public GuestException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new guest exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 * @param enableSuppression
	 *            the enable suppression
	 * @param writableStackTrace
	 *            the writable stack trace
	 */
	public GuestException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
